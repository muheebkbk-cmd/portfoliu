import Navbar from './components/Navbar'
import Hero from './components/Hero'
import { About, Skills, Projects, Services } from './components/Sections'
import { Contact, Footer } from './components/Contact'
export default function App() {
  return (<><Navbar /><main><Hero /><About /><Skills /><Projects /><Services /><Contact /></main><Footer /></>)
}
