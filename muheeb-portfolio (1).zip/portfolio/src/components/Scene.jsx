import { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, Sparkles, Trail, MeshDistortMaterial, Edges } from '@react-three/drei'
function Orbit({ r = 2.6, s = 1, t = 0, y = 0 }) {
  const m = useRef()
  useFrame(({ clock }) => { const a = clock.elapsedTime * s + t; m.current.position.set(Math.cos(a) * r, y + Math.sin(a * 1.3) * 0.6, Math.sin(a) * r) })
  return (
    <Trail width={1.4} length={8} color="#ff1e2d" attenuation={(k) => k * k}>
      <mesh ref={m}><sphereGeometry args={[0.07, 12, 12]} /><meshBasicMaterial color="#ff5060" /></mesh>
    </Trail>
  )
}
function GlassCard({ position, rotation, size = [1.5, 0.95] }) {
  return (
    <Float speed={2} rotationIntensity={0.4} floatIntensity={1.2}>
      <mesh position={position} rotation={rotation}>
        <boxGeometry args={[size[0], size[1], 0.05]} />
        <meshPhysicalMaterial color="#2a050a" transparent opacity={0.45} roughness={0.15} metalness={0.6} emissive="#5a0610" emissiveIntensity={0.4} />
        <Edges color="#ff1e2d" />
      </mesh>
    </Float>
  )
}
function Rig() {
  const g = useRef(), core = useRef()
  useFrame(({ pointer }, d) => {
    g.current.rotation.y += (pointer.x * 0.6 - g.current.rotation.y) * 0.06
    g.current.rotation.x += (-pointer.y * 0.35 - g.current.rotation.x) * 0.06
    core.current.rotation.y += d * 0.35; core.current.rotation.x += d * 0.15
  })
  return (
    <group ref={g}>
      <Float speed={1.6} floatIntensity={1} rotationIntensity={0.2}>
        <group ref={core}>
          <mesh><torusKnotGeometry args={[0.95, 0.28, 220, 32]} /><meshStandardMaterial color="#120305" metalness={1} roughness={0.2} emissive="#ff1e2d" emissiveIntensity={0.35} wireframe /></mesh>
          <mesh scale={0.7}><icosahedronGeometry args={[1, 3]} /><MeshDistortMaterial color="#ff1e2d" emissive="#c00a18" emissiveIntensity={1.4} distort={0.35} speed={2} roughness={0.2} /></mesh>
        </group>
      </Float>
      <GlassCard position={[2.1, 1.1, 0.4]} rotation={[0.1, -0.5, 0.1]} />
      <GlassCard position={[-2.2, -0.9, 0.6]} rotation={[-0.1, 0.5, -0.1]} size={[1.3, 0.8]} />
      <GlassCard position={[1.6, -1.6, -0.6]} rotation={[0.2, -0.3, 0.2]} size={[1.1, 0.7]} />
      <Orbit r={2.6} s={0.9} /><Orbit r={3.1} s={-0.6} t={2} y={0.4} /><Orbit r={2.2} s={1.3} t={4} y={-0.4} />
    </group>
  )
}
export default function Scene() {
  return (
    <Canvas dpr={[1, 1.75]} camera={{ position: [0, 0, 6.5], fov: 45 }} gl={{ antialias: true, alpha: true }}>
      <ambientLight intensity={0.3} />
      <pointLight position={[4, 3, 4]} intensity={60} color="#ff1e2d" />
      <pointLight position={[-4, -2, 2]} intensity={30} color="#7a0610" />
      <directionalLight position={[0, 4, 5]} intensity={0.8} />
      <Rig />
      <Sparkles count={70} scale={[9, 6, 6]} size={2.5} speed={0.25} color="#ff4050" opacity={0.7} />
    </Canvas>
  )
}
