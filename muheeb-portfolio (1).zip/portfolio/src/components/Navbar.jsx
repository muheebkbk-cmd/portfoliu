import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Menu, X } from 'lucide-react'
const links = ['Home', 'About', 'Skills', 'Projects', 'Services', 'Contact']
export default function Navbar() {
  const [open, setOpen] = useState(false), [solid, setSolid] = useState(false)
  useEffect(() => { const f = () => setSolid(window.scrollY > 20); f(); window.addEventListener('scroll', f, { passive: true }); return () => window.removeEventListener('scroll', f) }, [])
  return (
    <header className={`fixed inset-x-0 top-0 z-50 border-b transition-all duration-300 ${solid || open ? 'border-white/10 bg-black/60 backdrop-blur-xl' : 'border-transparent'}`}>
      <div className="mx-auto flex h-[68px] max-w-7xl items-center justify-between px-5">
        <a href="#home" className="font-display text-lg font-bold tracking-widest">MUHEEB<span className="text-red">.</span></a>
        <nav className="hidden items-center gap-8 lg:flex" aria-label="Main">
          {links.map((l) => <a key={l} href={`#${l.toLowerCase()}`} className="text-xs font-bold tracking-[.18em] text-white/70 transition hover:text-red">{l.toUpperCase()}</a>)}
        </nav>
        <a href="#contact" className="hidden rounded-full bg-red px-6 py-2.5 text-xs font-bold tracking-widest text-white shadow-[0_0_24px_-4px_#ff1e2d] transition hover:scale-105 lg:block">LET'S TALK</a>
        <button className="lg:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden lg:hidden" aria-label="Mobile">
            <div className="flex flex-col gap-1 px-5 pb-6">
              {links.map((l) => <a key={l} onClick={() => setOpen(false)} href={`#${l.toLowerCase()}`} className="border-b border-white/5 py-3 text-sm font-bold tracking-[.18em]">{l.toUpperCase()}</a>)}
              <a href="#contact" onClick={() => setOpen(false)} className="mt-4 rounded-full bg-red py-3 text-center text-xs font-bold tracking-widest">LET'S TALK</a>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  )
}
