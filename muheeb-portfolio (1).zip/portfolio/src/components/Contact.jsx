import { useState } from 'react'
import { Mail, Phone, MessageCircle, MapPin } from 'lucide-react'
import { Title } from './ui'
const field = 'w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3.5 text-sm outline-none transition focus:border-red'
export function Contact() {
  const [f, setF] = useState({ name: '', email: '', msg: '' })
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const send = (e) => { e.preventDefault(); window.location.href = `mailto:muheebkbk@gmail.com?subject=${encodeURIComponent('Project inquiry from ' + f.name)}&body=${encodeURIComponent(f.msg + '\n\n' + f.name + '\n' + f.email)}` }
  const info = [[MessageCircle, 'WhatsApp', '0340-1806309', 'https://wa.me/923401806309'], [Mail, 'Email', 'muheebkbk@gmail.com', 'mailto:muheebkbk@gmail.com'], [Phone, 'Phone', '0340-1806309', 'tel:+923401806309'], [MapPin, 'Location', 'Karachi, Pakistan']]
  return (
    <section id="contact" className="relative overflow-hidden bg-coal">
      <div className="pointer-events-none absolute -bottom-40 left-1/2 h-96 w-[700px] -translate-x-1/2 rounded-full bg-red/20 blur-[130px]" />
      <div className="relative mx-auto max-w-7xl px-5 py-24">
        <Title tag="LET'S WORK TOGETHER">CONTACT</Title>
        <div className="grid gap-12 lg:grid-cols-2">
          <div className="space-y-4">
            <p className="max-w-md text-xl text-white/75">You bring the product. I'll bring the buyers. Tell me about your business and I'll reply with a plan.</p>
            {info.map(([I, l, v, h]) => { const C = h ? 'a' : 'div'; return <C key={l} href={h} className="flex items-center gap-4 rounded-xl border border-white/10 p-4 transition hover:border-red/60"><span className="grid h-11 w-11 place-items-center rounded-lg bg-red/15 text-red"><I size={20} /></span><span><span className="block text-xs text-white/45">{l}</span>{v}</span></C> })}
          </div>
          <form onSubmit={send} className="space-y-4 rounded-2xl border border-white/10 bg-black/30 p-6 md:p-8">
            <input required className={field} placeholder="Your name" value={f.name} onChange={set('name')} aria-label="Your name" />
            <input required type="email" className={field} placeholder="Your email" value={f.email} onChange={set('email')} aria-label="Your email" />
            <textarea required rows={5} className={field} placeholder="Tell me about your project" value={f.msg} onChange={set('msg')} aria-label="Message" />
            <button className="w-full rounded-full bg-red py-4 text-xs font-bold tracking-widest shadow-[0_0_30px_-6px_#ff1e2d] transition hover:-translate-y-1">SEND MESSAGE</button>
          </form>
        </div>
      </div>
    </section>
  )
}
export const Footer = () => <footer className="border-t border-white/10 py-8 text-center text-sm text-white/40">© 2026 Muheeb Ur Rahman. Karachi, Pakistan.</footer>
