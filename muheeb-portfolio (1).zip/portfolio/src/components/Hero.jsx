import { Suspense, lazy } from 'react'
import { motion } from 'framer-motion'
const Scene = lazy(() => import('./Scene'))
const up = (d) => ({ initial: { opacity: 0, y: 30 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.6, delay: d } })
export default function Hero() {
  return (
    <section id="home" className="relative flex min-h-screen items-center overflow-hidden pt-24">
      <div className="pointer-events-none absolute right-[-10%] top-1/2 h-[620px] w-[620px] -translate-y-1/2 rounded-full bg-red/25 blur-[140px]" />
      <div className="relative mx-auto grid w-full max-w-7xl items-center gap-4 px-5 lg:grid-cols-2">
        <div>
          <motion.p {...up(0)} className="mb-5 text-[11px] font-bold tracking-[.28em] text-red sm:text-xs">DIGITAL MARKETER • SEO • SOCIAL MEDIA</motion.p>
          <motion.h1 {...up(0.1)} className="font-display text-4xl font-extrabold leading-[1.05] sm:text-5xl xl:text-6xl">MUHEEB UR RAHMAN</motion.h1>
          <motion.h2 {...up(0.2)} className="mt-4 bg-gradient-to-r from-white via-white to-red bg-clip-text font-display text-2xl font-bold text-transparent sm:text-3xl xl:text-4xl">Turning Ideas Into Digital Growth.</motion.h2>
          <motion.p {...up(0.3)} className="mt-6 max-w-xl text-base text-white/65 sm:text-lg">I help businesses build a stronger online presence through digital marketing, SEO, social media management and web solutions.</motion.p>
          <motion.div {...up(0.4)} className="mt-9 flex flex-wrap gap-4">
            <a href="#projects" className="rounded-full bg-red px-8 py-4 text-xs font-bold tracking-widest shadow-[0_0_30px_-6px_#ff1e2d] transition hover:-translate-y-1 hover:shadow-[0_8px_40px_-6px_#ff1e2d]">VIEW MY WORK</a>
            <a href="#contact" className="rounded-full border border-white/25 px-8 py-4 text-xs font-bold tracking-widest transition hover:-translate-y-1 hover:border-red hover:text-red">CONTACT ME</a>
          </motion.div>
        </div>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: 0.3 }} className="h-[380px] sm:h-[480px] lg:h-[640px]">
          <Suspense fallback={null}><Scene /></Suspense>
        </motion.div>
      </div>
    </section>
  )
}
