import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'
export const Title = ({ tag, children }) => (
  <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="mb-12">
    <p className="mb-3 text-xs tracking-[.3em] text-red">{tag}</p>
    <h2 className="font-display text-3xl font-bold md:text-5xl">{children}</h2>
  </motion.div>
)
export function Tilt({ children, className = '' }) {
  const x = useMotionValue(0), y = useMotionValue(0)
  const rx = useSpring(useTransform(y, [-.5, .5], [9, -9]), { stiffness: 200, damping: 20 })
  const ry = useSpring(useTransform(x, [-.5, .5], [-9, 9]), { stiffness: 200, damping: 20 })
  const move = (e) => { const r = e.currentTarget.getBoundingClientRect(); x.set((e.clientX - r.left) / r.width - .5); y.set((e.clientY - r.top) / r.height - .5) }
  return (
    <motion.div style={{ rotateX: rx, rotateY: ry, transformPerspective: 900 }} onMouseMove={move} onMouseLeave={() => { x.set(0); y.set(0) }}
      initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
      className={`rounded-2xl border border-white/10 bg-gradient-to-br from-white/[.07] to-transparent p-6 transition-[border-color,box-shadow] duration-300 hover:border-red/60 hover:shadow-[0_0_40px_-12px_#ff1e2d] ${className}`}>
      {children}
    </motion.div>
  )
}
