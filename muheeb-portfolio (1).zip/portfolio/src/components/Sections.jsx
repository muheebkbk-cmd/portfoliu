import { Globe, Search, MousePointerClick, Target, Share2, Mail, Users, Layers } from 'lucide-react'
import { Title, Tilt } from './ui'
const wrap = 'mx-auto max-w-7xl px-5 py-24'

export function About() {
  const cards = [['Digital Marketing', 'Campaigns built around real buyers', Target], ['SEO', 'Found on Google by the right people', Search], ['Social Media', 'Content that grows your brand', Share2], ['Web Projects', 'Live client website delivered', Globe]]
  return (
    <section id="about" className="bg-coal"><div className={wrap}>
      <Title tag="WHO I AM">ABOUT ME</Title>
      <div className="grid items-center gap-12 lg:grid-cols-[320px_1fr]">
        <div className="relative mx-auto w-64 lg:w-full">
          <div className="absolute inset-0 translate-x-3 translate-y-3 rounded-3xl bg-gradient-to-br from-red to-deep" />
          <img src={`${import.meta.env.BASE_URL}muheeb.jpg`} alt="Muheeb Ur Rahman" width="320" height="480" loading="lazy" className="relative aspect-[3/4] w-full rounded-3xl border border-white/10 object-cover object-top" />
        </div>
        <div>
          <p className="text-xl font-medium leading-relaxed md:text-2xl">Hi, I'm Muheeb ur Rahman, a digital marketer focused on helping businesses improve their online presence.</p>
          <p className="mt-5 text-white/60">I work across digital marketing, SEO, social media marketing, lead generation, email marketing and web development, so you deal with one person who understands both the website and the marketing. Based in Karachi, trained at Aptech Computer Education, working with clients on Fiverr, Upwork and Contra.</p>
          <div className="mt-10 grid grid-cols-2 gap-4">
            {cards.map(([t, d, I]) => <Tilt key={t}><I className="mb-4 text-red" /><h3 className="font-display text-sm font-bold">{t}</h3><p className="mt-1 text-sm text-white/55">{d}</p></Tilt>)}
          </div>
        </div>
      </div>
    </div></section>
  )
}

export function Skills() {
  const s = [['Digital Marketing', 'Strategy, funnels and campaign planning', Target], ['SEO', 'Technical and on-page optimisation', Search], ['Social Media Management', 'Content, captions and community', Share2], ['Lead Generation', 'Forms, ads and landing pages that convert', Users], ['Email Marketing', 'Campaigns that bring customers back', Mail], ['Web Development', 'HTML, CSS, JavaScript, Netlify', Layers]]
  return (
    <section id="skills"><div className={wrap}>
      <Title tag="WHAT I'M GOOD AT">SKILLS</Title>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {s.map(([t, d, I]) => <Tilt key={t} className="group"><div className="mb-5 grid h-12 w-12 place-items-center rounded-xl bg-red/15 text-red transition group-hover:bg-red group-hover:text-white"><I size={22} /></div><h3 className="font-display text-base font-bold">{t}</h3><p className="mt-2 text-sm text-white/55">{d}</p></Tilt>)}
      </div>
    </div></section>
  )
}

export function Projects() {
  const sol = ['Hero with one clear action: "Request a Free Quote"', 'Filterable gallery of 20+ real projects in 5 categories', '4-step process: Consult, Select, Quote, Install', 'Quote form with a service dropdown, so leads arrive qualified', 'Local trust signals: showroom location, call button, email']
  return (
    <section id="projects" className="bg-coal"><div className={wrap}>
      <Title tag="SELECTED WORK">PROJECTS</Title>
      <Tilt className="!p-0 overflow-hidden">
        <img src={`${import.meta.env.BASE_URL}pakistan-marble-stone.jpg`} alt="Pakistan Marble Stone website on laptop and phone" width="1400" height="933" loading="lazy" className="w-full" />
        <div className="grid gap-10 p-6 md:p-10 lg:grid-cols-2">
          <div>
            <p className="text-xs tracking-[.25em] text-red">WEB DEVELOPMENT + DIGITAL MARKETING</p>
            <h3 className="mt-3 font-display text-2xl font-bold md:text-3xl">Pakistan Marble Stone</h3>
            <p className="mt-1 text-sm text-white/45">Client: Sadiq Khan. Ittihad Town and Old Golimar Marble Market, Karachi.</p>
            <p className="mt-5 text-white/65"><b className="text-white">Challenge:</b> a Karachi stone and cladding business with great work but no online presence. Customers saw photos on WhatsApp and trust was hard to build. The goal: a professional website that shows the work and brings in quote requests.</p>
            <p className="mt-4 text-white/65"><b className="text-white">Marketing support:</b> Google Ads campaigns with tailored ad copy, international marble export market research, and Alibaba seller account setup.</p>
            <a href="https://pakistan-marble-stone.netlify.app/" target="_blank" rel="noopener noreferrer" className="mt-7 inline-block rounded-full bg-red px-7 py-3.5 text-xs font-bold tracking-widest transition hover:-translate-y-1">VISIT LIVE SITE</a>
          </div>
          <div>
            <h4 className="mb-4 font-display text-sm font-bold">THE SOLUTION</h4>
            <ul className="space-y-3 text-white/70">{sol.map((x) => <li key={x} className="flex gap-3"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-red" />{x}</li>)}</ul>
            <p className="mt-6 text-sm text-white/45">HTML, CSS, JavaScript, Netlify, Google Ads, copywriting, local SEO basics, UX for lead generation.</p>
          </div>
        </div>
      </Tilt>
    </div></section>
  )
}

export function Services() {
  const s = [['Web Development', 'Fast, mobile-first websites built to bring in inquiries.', Globe], ['SEO', 'Get found on Google by customers already searching.', Search], ['Google Ads', 'Search campaigns with ad copy aimed at ready buyers.', MousePointerClick], ['Meta Ads', 'Facebook and Instagram ads for the right audience.', Target], ['Social Media Marketing', 'Content that builds your brand and engagement.', Share2], ['Email Marketing', 'Campaigns that turn first-time buyers into regulars.', Mail]]
  return (
    <section id="services"><div className={wrap}>
      <Title tag="HOW I CAN HELP">SERVICES</Title>
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {s.map(([t, d, I]) => <Tilt key={t}><I className="mb-5 text-red" size={28} /><h3 className="font-display text-base font-bold">{t}</h3><p className="mt-2 text-sm text-white/55">{d}</p></Tilt>)}
      </div>
    </div></section>
  )
}
